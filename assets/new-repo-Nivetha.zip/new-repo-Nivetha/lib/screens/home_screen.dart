// import 'package:flutter/material.dart';
// import 'package:google/widgets/common_widgets.dart';
// import 'package:google/widgets/utils.dart';
//
//
// class HomeScreen extends StatefulWidget {
//   @override
//   _HomeScreenState createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: <Widget> [
//         // LargeText("Fist Message "),
//         // cardView(),
//       ],
//     );
//   }
// }
