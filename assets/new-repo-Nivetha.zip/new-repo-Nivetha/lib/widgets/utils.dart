/*
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget cardView(){
  return Card(
    child: Text("Card Text"),
  );
}*/
