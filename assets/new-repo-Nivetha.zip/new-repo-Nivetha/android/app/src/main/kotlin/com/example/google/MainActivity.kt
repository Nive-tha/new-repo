package com.example.google

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
